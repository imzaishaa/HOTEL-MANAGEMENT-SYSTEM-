CREATE DATABASE HotelManagement;
USE HotelManagement;

CREATE TABLE Hotel (
    HotelID INT AUTO_INCREMENT PRIMARY KEY,
    HotelName VARCHAR(100) NOT NULL,
    Address VARCHAR(255) NOT NULL,
    Phone VARCHAR(15) NOT NULL
);

CREATE TABLE Room (
    RoomID INT AUTO_INCREMENT PRIMARY KEY,
    RoomType VARCHAR(50) NOT NULL,
    PricePerNight DECIMAL(10, 2) NOT NULL CHECK (PricePerNight > 0),
    HotelID INT NOT NULL,
    FOREIGN KEY (HotelID) REFERENCES Hotel(HotelID)
);

CREATE TABLE Guest (
    GuestID INT AUTO_INCREMENT PRIMARY KEY,
    FirstName VARCHAR(50) NOT NULL,
    LastName VARCHAR(50) NOT NULL,
    Phone VARCHAR(15) UNIQUE,
    Email VARCHAR(100),
    Address VARCHAR(255)
);

CREATE TABLE Reservation (
    ReservationID INT AUTO_INCREMENT PRIMARY KEY,
    GuestID INT NOT NULL,
    RoomID INT NOT NULL,
    CheckInDate DATE NOT NULL,
    CheckOutDate DATE NOT NULL,
    TotalAmount DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (GuestID) REFERENCES Guest(GuestID),
    FOREIGN KEY (RoomID) REFERENCES Room(RoomID)
);

CREATE TABLE Staff (
    StaffID INT AUTO_INCREMENT PRIMARY KEY,
    FirstName VARCHAR(50) NOT NULL,
    LastName VARCHAR(50) NOT NULL,
    Position VARCHAR(50),
    Phone VARCHAR(15),
    HotelID INT NOT NULL,
    FOREIGN KEY (HotelID) REFERENCES Hotel(HotelID)
);
-- Insert into Hotel
INSERT INTO Hotel (HotelName, Address, Phone)
VALUES 
('Pearl Continental', 'Mall Road, Lahore', '042-35781234'),
('Serena Hotel', 'G-5, Islamabad', '051-2874567'),
('Marriott', 'F-8, Islamabad', '051-2293847'),
('Beach Luxury Hotel', 'Clifton, Karachi', '021-34567890'),
('Hotel One', 'Satellite Town, Rawalpindi', '051-4856739');

-- Insert into Room
INSERT INTO Room (RoomType, PricePerNight, HotelID)
VALUES 
('Single', 7000.00, 1),
('Double', 10000.00, 1),
('Suite', 22000.00, 1),
('Economy', 5000.00, 2),
('Deluxe', 18000.00, 3),
('Executive Suite', 30000.00, 3),
('Presidential Suite', 50000.00, 4),
('Family Room', 15000.00, 5),
('Penthouse', 60000.00, 4);

-- Insert into Guest
INSERT INTO Guest (FirstName, LastName, Phone, Email, Address)
VALUES 
('Zara', 'Sheikh', '0342-6783456', 'zarasheikh@yahoo.com', 'Flat 15, Clifton, Karachi'),
('Omer', 'Farooq', '0334-5671234', 'omerf@hotmail.com', 'Plot 120, DHA Phase 6, Karachi'),
('Hassan', 'Ali', '0302-3456789', 'hassanali@gmail.com', 'Sector D, Bahria Town, Lahore'),
('Maryam', 'Shah', '0321-8765432', 'maryam.shah@gmail.com', 'Block C, Gulistan-e-Johar, Karachi'),
('Arman', 'Qureshi', '0314-7654321', 'armanq@gmail.com', 'Street 3, F-7, Islamabad'),
('Nimra', 'Yousaf', '0309-6543278', 'nimray@gmail.com', 'House 25, Gulberg, Lahore'),
('Fahad', 'Ahmed', '0341-6781234', 'fahadahmed@gmail.com', 'Apartment 4, Saddar, Karachi');

-- Insert into Reservation
INSERT INTO Reservation (GuestID, RoomID, CheckInDate, CheckOutDate, TotalAmount)
VALUES 
(1, 3, '2024-03-01', '2024-03-05', 88000.00),
(2, 5, '2024-02-15', '2024-02-18', 54000.00),
(3, 7, '2024-01-20', '2024-01-27', 350000.00),
(4, 8, '2024-04-10', '2024-04-13', 45000.00),
(5, 6, '2024-05-01', '2024-05-03', 60000.00),
(6, 9, '2024-03-25', '2024-03-30', 300000.00),
(7, 1, '2024-04-15', '2024-04-17', 14000.00);

-- Insert into Staff
INSERT INTO Staff (FirstName, LastName, Position, Phone, HotelID)
VALUES 
('Asma', 'Rehman', 'Manager', '0340-5678912', 1),
('Tariq', 'Hussain', 'Chef', '0312-4567812', 1),
('Rubina', 'Ali', 'Receptionist', '0336-5671234', 2),
('Kamran', 'Nawaz', 'Bellboy', '0309-1234567', 3),
('Sadia', 'Malik', 'Manager', '0315-2345678', 4),
('Faizan', 'Shaikh', 'Chef', '0348-9876543', 5),
('Naveed', 'Iqbal', 'Security', '0322-4567890', 3),
('Rukhsar', 'Ahmed', 'Housekeeper', '0345-3216547', 4);
 -- Retrieve Specific Columns and Use JOIN
 SELECT Guest.FirstName, Guest.LastName, Hotel.HotelName, Room.RoomType, Reservation.CheckInDate, Reservation.CheckOutDate
FROM Reservation
JOIN Guest ON Reservation.GuestID = Guest.GuestID
JOIN Room ON Reservation.RoomID = Room.RoomID
JOIN Hotel ON Room.HotelID = Hotel.HotelID;

-- Use Aggregate Functions and Grouping
SELECT Hotel.HotelName, COUNT(Room.RoomID) AS TotalRooms, AVG(Room.PricePerNight) AS AveragePrice
FROM Room
JOIN Hotel ON Room.HotelID = Hotel.HotelID
GROUP BY Hotel.HotelName
HAVING AVG(Room.PricePerNight) > 100;

-- Logical Operators and Filtering
SELECT * 
FROM Room 
WHERE PricePerNight BETWEEN 100 AND 200 
AND RoomType LIKE '%Suite%';

SELECT GuestID, FirstName, LastName
FROM Guest
WHERE GuestID IN (
    SELECT GuestID 
    FROM Reservation 
    WHERE TotalAmount > 500
);
SELECT * FROM guest;
SELECT * FROM hotel;
SELECT * FROM reservation;
SELECT * FROM room;
SELECT * FROM staff;